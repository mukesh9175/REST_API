package com.task.rest.projecttask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjecttaskApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjecttaskApplication.class, args);
		System.out.println("Run program sucessfully");
	}

}
