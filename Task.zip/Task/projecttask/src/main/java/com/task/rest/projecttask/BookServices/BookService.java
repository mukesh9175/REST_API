package com.task.rest.projecttask.BookServices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.rest.projecttask.Dao.BookRepository;
import com.task.rest.projecttask.Entities.Book;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBooks() {
        return (List<Book>) this.bookRepository.findAll();
    }

    public Book getBooksById(int id) {
        return this.bookRepository.findById(id);
    }

    public Book AddBooks(Book b) {
        return bookRepository.save(b);
    }

    public void deleteBooks(int bid) {
        bookRepository.deleteById(bid);
    }

    public void updateBook(Book book, int bookId) {
        book.setBookId(bookId);
        bookRepository.save(book);
    }
}
